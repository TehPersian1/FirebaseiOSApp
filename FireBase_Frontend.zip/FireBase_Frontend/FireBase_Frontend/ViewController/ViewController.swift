//
//  ViewController.swift
//  FireBase_Frontend
//
//  Created by Afrasiabi, Shervin on 10/6/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LoginButton: UIButton!
    @IBOutlet weak var SignUpButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        Init()
        // Do any additional setup after loading the view.
    }

    func Init(){
        Utilities.styleHollowButton(SignUpButton)
        Utilities.styleFilledButton(LoginButton)
    }

}

